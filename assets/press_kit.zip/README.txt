Steelhold: Tank Battle. Press images, free to use in coverage of the game.
Screenshots captured on iPad. Contact: val.mail.dev@gmail.com
